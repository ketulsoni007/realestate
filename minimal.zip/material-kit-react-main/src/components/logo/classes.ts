export const logoClasses = {
  root: 'mnl__logo__root',
};
